#include<iostream.h>
#include<conio.h>
int main()
{
    int a,b;
    cout<<"Enter the Number : ";
    cin>>a>>b;
    cout<<"Before Swapping a : "<<a<<"b = "<<b;
    a=a+b;
    b=a-b;
    a=a-b;
    cout<<"After Swapping a : "<<a<<"b = "<<b;
    getch();
    return 0;
}