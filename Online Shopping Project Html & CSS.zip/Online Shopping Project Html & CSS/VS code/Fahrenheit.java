import java.util.Scanner;
public class Fahrenheit {
    public static void main(String[] args){
        float temperature;

        try (Scanner in = new Scanner(System.in)) {
            System.out.println("Enter the temperature in farenheit");
            temperature=in.nextInt();
        }
        temperature = ((temperature-32)*5)/9;
        System.out.println("Temperature in Celcius = "+ temperature);

    }
    
}
