import java.util.Scanner;

public class Addition {

    public static void main(String[] args){
        String s1 = "Delhi";
        String s2 =  "Hyderabad";
        String s3 =  "Pune";
       try (Scanner sc = new Scanner(System.in)) {
        System.out.print("enter the city name: ");
           String sa = sc.nextLine();
           if(s1.equals(sa)){
            System.out.println("hii");
           }else if(s2.equals(sa)){
            System.out.println("by");
           }else if(s3.equals(sa)){
            System.out.println("yelcome");
           }
           else{
            System.out.println("le");
           }
    }
   }
} 

