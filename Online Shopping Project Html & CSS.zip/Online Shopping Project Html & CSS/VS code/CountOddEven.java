import java.util.Scanner;
public class CountOddEven {
    public static void main(String[] args){
     try (Scanner sc = new Scanner(System.in)) {
      System.out.println("Enter the random number : ");
       int n[] = new int[8];
       int i;
       for(i=0;i<8;i++)
       {
          n[i]=sc.nextInt();

       }

       //Display the numbes 

       int countEven =0;
       int countOdd =0;
       System.out.println("Enter number is : ");
       for(i=0;i<8;i++)
       {
          System.out.println(" "+n[i]);
       }
        System.out.println();

        //Count Odd and Even
        for(i=0;i<8;i++)
        {
          if (n[i]%2==0) {
              countEven++;
              
          } else {
              countOdd++;
              
          }
        }
        System.out.println("Count of Even number is : "+countEven);
        System.out.println("Count of Odd number is : "+countOdd);
    }

    }
    
}
