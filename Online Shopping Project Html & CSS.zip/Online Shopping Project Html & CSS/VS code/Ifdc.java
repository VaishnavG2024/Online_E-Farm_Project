public class Ifdc {
    public static void main (String[] args){

        int a = 12;
        System.out.println("Integer : " +a);
        float b = 30.123234f;
        System.out.println("Float : "+b);
        double c = 4.5675465d;
        System.out.println("Double : "+c); 
        char d = 'D';
        System.out.println("Character : "+d);
       
    }
    
}
