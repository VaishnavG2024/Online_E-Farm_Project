public class AddSub {
    public static void main(String[] args){
        int a=2;
        int b=2;

        System.out.println("Addtion is : "+(a+b));
        System.out.println("Substraction  is : "+(a-b));
        System.out.println("Multiplication is : "+(a*b));
        System.out.println("Division is : " +(a/b));
    }
    
}
