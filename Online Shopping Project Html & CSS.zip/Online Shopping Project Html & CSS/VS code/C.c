#include<stdio.h>
#include<conio.h>
int main()
{
  int i;
  int arr[3]={1,2,3};
  printf("%d",arr[3]);
}
