import java.util.Scanner;
public class Largestno {
    
    public static void main(String[] args){
    int x, y, z;
    System.out.println("Enter the three integer : ");
    try (Scanner s = new Scanner(System.in)) {
        x = s.nextInt();
        y = s.nextInt();
        z = s.nextInt();
    }
    if(x>y && x>z)
    {
        System.out.println("x is largest");
    }else if(y>z && y>x){
        System.out.println("y is large");
    }else{
        System.out.println("Z is large");
    }
    }
}
